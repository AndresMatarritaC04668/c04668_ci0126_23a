﻿using System;

namespace LabCleanCode
{
    class NumberGuessing
    {
        public static void Play()
        {
            while (true)
            {
                int randno = Newnum(1, 101);
                int count = 1;
                while (true)
                {
                    Console.Write("Enter a number between 1 and 100 (0 to quit): ");
                    string inputString = Console.ReadLine();

                    if (inputString == "0")
                        return;

                    if (int.TryParse(inputString, out int input))
                    {
                        if (input < randno)
                        {
                            Console.WriteLine("Low, try again.");
                            ++count;
                            continue;
                        }
                        else if (input > randno)
                        {
                            Console.WriteLine("High, try again.");
                            ++count;
                            continue;
                        }
                        else
                        {
                            Console.WriteLine("You guessed it! The number was {0}!", randno);
                            Console.WriteLine("It took you {0} {1}.\n", count, count == 1 ? "try" : "tries");
                            break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. Please enter a valid number.");
                    }
                }
            }
        }

        ////////////////////////////////////////////////////////////////////////////////
        // Aleatorio
        ////////////////////////////////////////////////////////////////////////////////
        static int Newnum(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }
    }
}
