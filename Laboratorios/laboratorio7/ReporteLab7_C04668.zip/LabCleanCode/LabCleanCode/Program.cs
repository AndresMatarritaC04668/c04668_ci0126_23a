﻿namespace LabCleanCode
{
    class Program
    {
        /*
         * 2020-08-17: Roman
         * 2020-08-16: Hangman
         * 2020-08-15: NumberGuess
         * 2020-08-14: Letters
         */

        static void Main(string[] args)
        {
            //Console.WriteLine(Roman.To(3999));
            //Hangman.PlayHangman();
            //NumberGuessing.Play();
            //Letters.Count();
        }
    }
}
